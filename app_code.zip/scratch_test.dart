import 'dart:io';

import 'package:http/http.dart' as http;

void main() async {
  const token =
      '8d3b0a3e96524765a1d5e91863b4c2736fc9c9a7e4f0526daa8dc576927cb019';
  final client = http.Client();

  stdout.writeln('Testing Geocode...');
  final geocodeUri = Uri.parse('https://sonarpad.com/api/ors_geocode.php')
      .replace(queryParameters: {
    'q': 'via palestrina 45 torino',
    'size': '20',
    'layers': 'address,street,venue',
    'sources': 'osm,oa',
    'boundary.country': 'ITA',
    'language': 'it',
  });

  await client.get(geocodeUri, headers: {
    'User-Agent': 'SonarpadMobile/0.1 (https://sonarpad.com)',
    'Accept': 'application/json',
    'X-Sonarpad-Route-Token': token,
  });

  stdout.writeln('Geocode Status: \${geocodeResponse.statusCode}');
  stdout.writeln('Geocode Body: \${geocodeResponse.body}');
}
